export interface Variants {
		id: number;
		catalog_id: number;
		catalog_title: string;
		title: string;
		description: string;
		created_at: string;
		updated_at: string;
}
