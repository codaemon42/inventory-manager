import { FormsModule } from '@angular/forms';

import { InventoryComponent } from './inventory.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InventoryRoutingModule } from './inventory-routing.module';
import { NzTableModule } from 'ng-zorro-antd/table';


@NgModule({
  declarations: [InventoryComponent],
  imports: [
    CommonModule,
    NzTableModule,
    FormsModule,
    InventoryRoutingModule
  ]
})
export class InventoryModule { }
