import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-inventory',
  templateUrl: './add-inventory.component.html',
  styleUrls: ['./add-inventory.component.scss']
})
export class AddInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
