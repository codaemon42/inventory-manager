export interface Product {
		id: number;
		uuid: string;
		title: string;
		description: string;
		created_at: string;
		updated_at: string;
}
