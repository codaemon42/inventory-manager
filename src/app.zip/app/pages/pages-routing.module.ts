import { ProductModule } from './product/product.module';
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

const routes: Routes = [
      {
        path: '',
        loadChildren: () => import('../pages/home/home.module').then(m => m.HomeModule)
      },
      {
        path: 'inventory',
        loadChildren: () => import('../pages/inventory/inventory.module').then(m => m.InventoryModule)
      },
      {
        path: 'products',
        loadChildren: () => import('../pages/product/product.module').then(m => m.ProductModule)
      },
      {
        path: 'catalogs',
        loadChildren: () => import('../pages/catalog/catalog.module').then(m => m.CatalogModule)
      },
      {
        path: 'variants',
        loadChildren: () => import('../pages/variants/variants.module').then(m => m.VariantsModule)
      },
      {
        path: '',
        redirectTo: '/home',
        pathMatch: 'full'
      }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
})
export class PageRoutingModule { }
