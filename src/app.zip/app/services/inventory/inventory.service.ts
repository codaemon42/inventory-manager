import { environment } from './../../../environments/environment';
import { Inventory, InventoryRes } from './../../pages/inventory/inventory.model';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {

  _inventory = new BehaviorSubject<Inventory[]>([])

  constructor(private http: HttpClient) { }

  get inventory() {
    return this._inventory.asObservable();
  }

  fetchInventory(page=1) {
    const headers = this.headerOptions();
    return this.http.get<InventoryRes>(`${environment.url.base}/inventory/?page=${page}`, headers).pipe(
      take(1),
      tap(inventoryRes=>{
        console.log(inventoryRes);
        this._inventory.next(inventoryRes.data.result);
        return inventoryRes;
      })
    )
  }

    headerOptions() {
    const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MiwidXNlcm5hbWUiOiJuYWltNiIsInJvbGUiOiJhZG1pbiIsImlhdCI6MTY0MjUwMjcwNn0.3Bwd1J_YT6CmlYEciniDri8AhF8P2aejGCa5gmBlA7I';
    return {
      headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`})
    };
  }


}


