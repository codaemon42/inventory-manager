import { environment } from './../../../environments/environment';
import { Product } from './../../pages/product/product.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { take, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

_product = new BehaviorSubject<Product[]>([])

  constructor(private http: HttpClient) { }

  get product() {
    return this._product.asObservable();
  }

  fetch() {
    const headers = this.headerOptions();
    return this.http.get<Product[]>(`${environment.url.base}/products`, headers).pipe(
      take(1),
      tap(products=>{
        console.log(products);
        this._product.next(products);
        return products;
      })
    )
  }

  add(body){
    const headers = this.headerOptions();
    return this.http.post<any>(`${environment.url.base}/products`, body, headers).pipe(
      take(1),
      tap(product=>{
        console.log(product);
        this.product.pipe(take(1)).subscribe(products=>{
          const newProducts: any = products;
          newProducts.unshift(product)
          this._product.next(newProducts);
        })
        return product;
      })
    )
  }

  delete(id) {
    return this.http.post<any>(`${environment.url.base}/products/delete/${id}`, {}, this.headerOptions() ).pipe(
      take(1),
      tap(res => {
        this.product.pipe(take(1)).subscribe(products=>{
          const newProducts = products.filter(p=> p.id !== id);
          this._product.next(newProducts);
          return res;
        })
      })
    );
  }

  headerOptions() {
    const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MiwidXNlcm5hbWUiOiJuYWltNiIsInJvbGUiOiJhZG1pbiIsImlhdCI6MTY0MjUwMjcwNn0.3Bwd1J_YT6CmlYEciniDri8AhF8P2aejGCa5gmBlA7I';
    return {
      headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`})
    };
  }
}
