import { Variants } from './../../pages/variants/variants.model';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { take, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class VariantsService {
  _items = new BehaviorSubject<Variants[]>([])

  constructor(private http: HttpClient) { }

  get items() {
    return this._items.asObservable();
  }

  fetch() {
    const headers = this.headerOptions();
    return this.http.get<Variants[]>(`${environment.url.base}/variants`, headers).pipe(
      take(1),
      tap(resItems=>{
        console.log(resItems);
        this._items.next(resItems);
        return resItems;
      })
    )
  }

  add(body){
    const headers = this.headerOptions();
    return this.http.post<any>(`${environment.url.base}/variants`, body, headers).pipe(
      take(1),
      tap(resItem=>{
        console.log(resItem);
        this.items.pipe(take(1)).subscribe(items=>{
          const newItems: any = items;
          newItems.unshift(resItem);
          this._items.next(newItems);
        })
        return resItem;
      })
    )
  }

  delete(id) {
    return this.http.delete<any>(`${environment.url.base}/variants/${id}`, this.headerOptions() ).pipe(
      take(1),
      tap(res => {
        this.items.pipe(take(1)).subscribe(items=>{
          const newItems = items.filter(p=> p.id !== id);
          this._items.next(newItems);
          return res;
        })
      })
    );
  }

  headerOptions() {
    const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MiwidXNlcm5hbWUiOiJuYWltNiIsInJvbGUiOiJhZG1pbiIsImlhdCI6MTY0MjUwMjcwNn0.3Bwd1J_YT6CmlYEciniDri8AhF8P2aejGCa5gmBlA7I';
    return {
      headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`})
    };
  }
}
